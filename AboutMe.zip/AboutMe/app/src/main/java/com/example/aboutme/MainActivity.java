package com.example.aboutme;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private NavController navController;
    private Toolbar toolbar;
    private FloatingActionButton fab;
    private CoordinatorLayout coordinatorLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Views
        coordinatorLayout = findViewById(R.id.coordinatorLayout);
        toolbar = findViewById(R.id.toolbar);
        fab = findViewById(R.id.fab);

        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(Color.BLACK);
        toolbar.setTitleMarginStart(0); // Left-align title

        fab.setVisibility(View.VISIBLE);
        fab.setOnClickListener(this::showEmailPopup);

        // Navigation setup
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        navController = navHostFragment.getNavController();

        navController.addOnDestinationChangedListener((controller, destination, arguments) -> {
            int id = destination.getId();

            if (id == R.id.FirstFragment) {
                getSupportActionBar().setTitle(getString(R.string.biography_title));
                toolbar.setNavigationIcon(null);

            } else if (id == R.id.SecondFragment) {
                getSupportActionBar().setTitle(getString(R.string.hobbies_title));
                toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
                toolbar.setNavigationOnClickListener(v -> navController.navigateUp());

            } else if (id == R.id.ThirdFragment) {
                getSupportActionBar().setTitle(getString(R.string.contact_title));
                toolbar.setNavigationIcon(R.drawable.ic_arrow_back);
                toolbar.setNavigationOnClickListener(v -> navController.navigateUp());

                Toast.makeText(this, getString(R.string.going_to_contact), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showEmailPopup(View anchorView) {
        // Inflate popup layout
        View popupView = LayoutInflater.from(this).inflate(R.layout.popup_email, null);

        final PopupWindow popupWindow = new PopupWindow(
                popupView,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                false
        );

        popupWindow.setElevation(12f);
        popupWindow.setOutsideTouchable(true);

        // Calculate position to center horizontally above FAB
        int[] location = new int[2];
        anchorView.getLocationOnScreen(location);

        int fabY = location[1];
        int fabHeight = anchorView.getHeight();

        popupView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        int popupHeight = popupView.getMeasuredHeight();

        int verticalOffset = (int) (16 * getResources().getDisplayMetrics().density); // space above FAB

        // Show popup centered horizontally, above FAB
        int liftOffset = (int) (50 * getResources().getDisplayMetrics().density); // move popup up ~120dp

        popupWindow.showAtLocation(
                coordinatorLayout,
                Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM,
                0,
                fabHeight + verticalOffset + liftOffset
        );


        // Dismiss automatically after 2 seconds
        popupView.postDelayed(() -> {
            if (popupWindow.isShowing()) popupWindow.dismiss();
        }, 2000);
    }

    // Inflate three-dot menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // Handle menu item clicks
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            Toast.makeText(this, getString(R.string.action_settings), Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_about) {
            Toast.makeText(this, getString(R.string.action_about), Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
